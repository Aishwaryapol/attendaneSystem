async function startFaceRecognition() {
  try {
      const video = document.getElementById("video");
      const videoContainer = document.querySelector(".video-container");

      if (!video) {
          console.error("Video element not found.");
          return;
      }

      // Ensure video is playing before proceeding
      await new Promise((resolve) => {
          video.onloadedmetadata = resolve;
      });

      const labeledFaceDescriptors = await getLabeledFaceDescriptions();
      const faceMatcher = new faceapi.FaceMatcher(labeledFaceDescriptors, 0.7);
      
      const canvas = faceapi.createCanvasFromMedia(video);
      videoContainer.appendChild(canvas);

      const displaySize = { width: video.videoWidth, height: video.videoHeight };
      faceapi.matchDimensions(canvas, displaySize);

      async function detectFaces() {
          try {
              const detections = await faceapi.detectAllFaces(video)
                  .withFaceLandmarks()
                  .withFaceDescriptors();

              const resizedDetections = faceapi.resizeResults(detections, displaySize);
              const ctx = canvas.getContext("2d");
              ctx.clearRect(0, 0, canvas.width, canvas.height);

              const currentDetectedFaces = new Set();

              resizedDetections.forEach((detection) => {
                  const match = faceMatcher.findBestMatch(detection.descriptor);
                  if (match.label !== "unknown") {
                      currentDetectedFaces.add(match.label);
                  }
              });

              console.log("Currently Detected Faces:", Array.from(currentDetectedFaces));

              markAttendance(currentDetectedFaces);

              // Draw detection boxes
              resizedDetections.forEach((detection) => {
                  const box = detection.detection.box;
                  const match = faceMatcher.findBestMatch(detection.descriptor);
                  const label = match.label !== "unknown" ? match.label : "Unknown";

                  const drawBox = new faceapi.draw.DrawBox(box, { label });
                  drawBox.draw(canvas);
              });

              requestAnimationFrame(detectFaces);
          } catch (error) {
              console.error("Error detecting faces:", error);
          }
      }

      detectFaces();
  } catch (error) {
      console.error("Error starting face recognition:", error);
  }
}

function markAttendance(detectedFaces) {
  const attendanceColumnIndex = 4; // Adjustable column index
  document.querySelectorAll("#studentTableContainer tr").forEach((row, index) => {
      if (index === 0) return; // Skip header row
      const registrationNumber = row.cells[0]?.innerText.trim();
      if (registrationNumber) {
          row.cells[attendanceColumnIndex].innerText = detectedFaces.has(registrationNumber) ? "Present" : "Absent";
      }
  });
}
